package com.landrent.cleanbot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.widget.Toast

class CaptureService : Service() {
    companion object { @Volatile var running=false }
    private val binder = LocalBinder()
    private var projection: MediaProjection?=null
    private var display: VirtualDisplay?=null
    private var reader: ImageReader?=null
    inner class LocalBinder : Binder() { fun getService(): CaptureService = this@CaptureService }
    override fun onBind(intent: Intent?): IBinder = binder
    override fun onCreate() { super.onCreate(); createNotificationChannel(); startAsForeground() }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int { return START_NOT_STICKY }

    fun startProjection(resultCode:Int, data:Intent) {
        if (running) return
        try {
            val manager=getSystemService(android.media.projection.MediaProjectionManager::class.java)
            projection=manager.getMediaProjection(resultCode,data) ?: throw IllegalStateException("MediaProjection konnte nicht erstellt werden")
            projection!!.registerCallback(object: MediaProjection.Callback(){ override fun onStop(){ stopCapture() } }, null)
            val metrics=DisplayMetrics(); val wm=getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(metrics)
            val width=metrics.widthPixels; val height=metrics.heightPixels; val density=metrics.densityDpi
            reader=ImageReader.newInstance(width,height,PixelFormat.RGBA_8888,2)
            reader!!.setOnImageAvailableListener({ source ->
                val image=source.acquireLatestImage() ?: return@setOnImageAvailableListener
                try { val plane=image.planes[0]; val pixelStride=plane.pixelStride; val rowStride=plane.rowStride; val rowPadding=rowStride-pixelStride*width; val bitmapWidth=width+rowPadding/pixelStride; val bitmap=Bitmap.createBitmap(bitmapWidth,height,Bitmap.Config.ARGB_8888); bitmap.copyPixelsFromBuffer(plane.buffer); bitmap.recycle() } catch(_:Exception) {} finally { image.close() }
            }, null)
            display=projection!!.createVirtualDisplay("LandRentCapture",width,height,density,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader!!.surface,null,null)
            running=true
            Toast.makeText(this,"Bildschirmzugriff aktiv ✓",Toast.LENGTH_LONG).show()
        } catch(e:Exception) {
            Toast.makeText(this,"Bildschirm-Test Fehler: ${e.javaClass.simpleName}",Toast.LENGTH_LONG).show(); stopCapture()
        }
    }
    private fun stopCapture(){ running=false; display?.release(); reader?.close(); projection?.stop(); display=null; reader=null; projection=null }
    override fun onDestroy(){ stopCapture(); super.onDestroy() }
    private fun startAsForeground(){
        val notification=Notification.Builder(this,"capture").setContentTitle("LandRent 3 Gleiche NEUSTART").setContentText("Bildschirmzugriff aktiv").setSmallIcon(android.R.drawable.ic_menu_view).setOngoing(true).build()
        if(Build.VERSION.SDK_INT>=29) startForeground(1001,notification,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION) else startForeground(1001,notification)
    }
    private fun createNotificationChannel(){ if(Build.VERSION.SDK_INT>=26){ val c=NotificationChannel("capture","LandRent Bot",NotificationManager.IMPORTANCE_LOW); getSystemService(NotificationManager::class.java).createNotificationChannel(c) } }
}
