package com.landrent.cleanbot

import android.graphics.Bitmap
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Vision solver for the LandRent "3 Gleiche" board.
 *
 * It deliberately does not use a fixed fruit list.  It finds the white tile
 * faces, builds a compact HSV appearance histogram for every visible tile,
 * and compares those histograms with the current tray.
 */
class BotEngine(private val tap: (Float, Float) -> Boolean) {
    @Volatile var enabled = false
    private var lastTapAt = 0L
    private var consecutiveNoTap = 0

    private data class Tile(val cx: Float, val cy: Float, val desc: FloatArray, val white: Float)

    fun process(frame: Bitmap) {
        if (!enabled) return
        val now = SystemClock.uptimeMillis()
        if (now - lastTapAt < 700) return

        val tray = detectRegion(frame, 0.17f, 0.29f)
        val board = detectRegion(frame, 0.30f, 0.72f)
        if (board.isEmpty()) return

        // First finish a pair already present in the tray.
        var best: Tile? = null
        var bestScore = Float.NEGATIVE_INFINITY
        for (t in board) {
            val sameInTray = tray.maxOfOrNull { similarity(t.desc, it.desc) } ?: 0f
            val trayPair = tray.count { similarity(t.desc, it.desc) >= 0.82f }
            val score = when {
                trayPair >= 2 -> 1000f + sameInTray * 100f + t.white
                trayPair == 1 -> 700f + sameInTray * 100f + t.white
                else -> sameInTray * 250f + t.white
            }
            if (score > bestScore) {
                bestScore = score
                best = t
            }
        }

        // Do not tap a random green/background point. A candidate must really
        // look like a tile and must either match the tray or be a strong visible
        // tile candidate. This keeps the solver from filling all seven slots.
        if (best != null && bestScore > 35f) {
            if (tap(best.cx, best.cy)) {
                lastTapAt = now
                consecutiveNoTap = 0
            } else {
                consecutiveNoTap++
            }
        }
    }

    /** Find local maxima of "white tile face" density. */
    private fun detectRegion(src: Bitmap, topFrac: Float, bottomFrac: Float): List<Tile> {
        val w = src.width
        val h = src.height
        val y0 = (h * topFrac).toInt().coerceAtLeast(0)
        val y1 = (h * bottomFrac).toInt().coerceAtMost(h)
        val tileW = max(38, (w * 0.082f).toInt())
        val tileH = max(42, (w * 0.092f).toInt())
        val halfW = tileW / 2
        val halfH = tileH / 2
        val step = max(5, w / 120)
        val candidates = ArrayList<Tile>()

        var y = y0 + halfH
        while (y < y1 - halfH) {
            var x = halfW + w / 40
            while (x < w - halfW - w / 40) {
                val white = whiteDensity(src, x, y, halfW, halfH)
                if (white >= 0.34f) {
                    val desc = appearance(src, x, y, halfW, halfH)
                    candidates.add(Tile(x.toFloat(), y.toFloat(), desc, white))
                }
                x += step
            }
            y += step
        }

        // Non-maximum suppression. One physical tile should become one point.
        candidates.sortByDescending { it.white }
        val out = ArrayList<Tile>()
        val radius = w * 0.055f
        for (c in candidates) {
            if (out.none { abs(it.cx - c.cx) < radius && abs(it.cy - c.cy) < radius }) {
                out.add(c)
            }
        }
        return out
    }

    private fun whiteDensity(src: Bitmap, cx: Int, cy: Int, halfW: Int, halfH: Int): Float {
        val sx = max(3, halfW / 5)
        val sy = max(3, halfH / 5)
        var white = 0
        var total = 0
        var y = cy - halfH + sy / 2
        while (y <= cy + halfH - sy / 2) {
            var x = cx - halfW + sx / 2
            while (x <= cx + halfW - sx / 2) {
                val c = src.getPixel(x.coerceIn(0, src.width - 1), y.coerceIn(0, src.height - 1))
                val r = (c ushr 16) and 255
                val g = (c ushr 8) and 255
                val b = c and 255
                val mx = max(r, max(g, b))
                val mn = min(r, min(g, b))
                if (mx > 150 && mx - mn < 85) white++
                total++
                x += sx
            }
            y += sy
        }
        return if (total == 0) 0f else white.toFloat() / total
    }

    /** 12 hue bins + 4 saturation bins + 4 value bins, L1-normalised. */
    private fun appearance(src: Bitmap, cx: Int, cy: Int, halfW: Int, halfH: Int): FloatArray {
        val bins = FloatArray(20)
        val sx = max(3, halfW / 6)
        val sy = max(3, halfH / 6)
        var count = 0f
        var y = cy - halfH + sy / 2
        while (y <= cy + halfH - sy / 2) {
            var x = cx - halfW + sx / 2
            while (x <= cx + halfW - sx / 2) {
                val c = src.getPixel(x.coerceIn(0, src.width - 1), y.coerceIn(0, src.height - 1))
                val r = ((c ushr 16) and 255) / 255f
                val g = ((c ushr 8) and 255) / 255f
                val b = (c and 255) / 255f
                val mx = max(r, max(g, b))
                val mn = min(r, min(g, b))
                val d = mx - mn
                val s = if (mx == 0f) 0f else d / mx
                val v = mx
                if (s > 0.12f && v > 0.12f) {
                    var hue = 0f
                    if (d != 0f) {
                        hue = when (mx) {
                            r -> ((g - b) / d) % 6f
                            g -> (b - r) / d + 2f
                            else -> (r - g) / d + 4f
                        }
                        hue *= 60f
                        if (hue < 0f) hue += 360f
                    }
                    val hb = min(11, (hue / 30f).toInt())
                    bins[hb] += 1f
                    bins[12 + min(3, (s * 4f).toInt())] += 0.5f
                    bins[16 + min(3, (v * 4f).toInt())] += 0.25f
                } else {
                    bins[16 + min(3, (v * 4f).toInt())] += 0.25f
                }
                count += 1f
                x += sx
            }
            y += sy
        }
        if (count > 0f) for (i in bins.indices) bins[i] /= count
        return bins
    }

    private fun similarity(a: FloatArray, b: FloatArray): Float {
        var d = 0f
        for (i in a.indices) d += abs(a[i] - b[i])
        return 1f - min(1f, d * 1.8f)
    }
}
