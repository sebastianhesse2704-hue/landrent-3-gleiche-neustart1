package com.landrent.cleanbot

import android.graphics.Bitmap
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.sqrt

/** On-device visual solver. It groups tiles by appearance; no fruit list is hardcoded. */
class BotEngine(private val tap: (Float, Float) -> Boolean) {
    @Volatile var enabled = false
    private var lastTapAt = 0L

    fun process(frame: Bitmap) {
        if (!enabled) return
        val now = SystemClock.uptimeMillis()
        if (now - lastTapAt < 650) return

        val board = detectTiles(frame, 0.23f, 0.78f)
        if (board.isEmpty()) return
        val tray = detectTiles(frame, 0.06f, 0.20f)
        val boardGroups = cluster(board)
        val trayGroups = cluster(tray)

        var best: Tile? = null
        var bestScore = -1
        for (group in boardGroups) {
            val trayCount = trayGroups.count { appearanceDistance(group.first, it.first) < 0.16f }
            val score = when {
                trayCount >= 2 -> 1000 + trayCount
                group.size >= 3 -> 700 + group.size
                trayCount == 1 -> 400 + group.size
                else -> group.size
            }
            if (score > bestScore) { bestScore = score; best = group.firstOrNull() }
        }
        if (best != null && bestScore >= 400 && tap(best.cx, best.cy)) lastTapAt = now
    }

    private data class Tile(val cx: Float, val cy: Float, val desc: FloatArray)

    private fun cluster(tiles: List<Tile>): List<List<Tile>> {
        val out = mutableListOf<MutableList<Tile>>()
        for (t in tiles) {
            val target = out.firstOrNull { appearanceDistance(t, it[0]) < 0.16f }
            if (target == null) out += mutableListOf(t) else target.add(t)
        }
        return out
    }

    private fun appearanceDistance(a: Tile, b: Tile): Float {
        var s = 0.0
        for (i in a.desc.indices) { val d = a.desc[i] - b.desc[i]; s += d * d }
        return sqrt(s / a.desc.size).toFloat()
    }

    private fun detectTiles(src: Bitmap, topFrac: Float, bottomFrac: Float): List<Tile> {
        val w = src.width; val h = src.height
        val y0 = (h * topFrac).toInt().coerceAtLeast(0)
        val y1 = (h * bottomFrac).toInt().coerceAtMost(h)
        val scale = 3
        val sw = w / scale; val sh = (y1 - y0) / scale
        if (sw < 100 || sh < 100) return emptyList()

        val mask = BooleanArray(sw * sh)
        for (yy in 0 until sh) for (xx in 0 until sw) {
            val sx = xx * scale + scale / 2
            val sy = y0 + yy * scale + scale / 2
            val c = src.getPixel(sx.coerceIn(0, w - 1), sy.coerceIn(0, h - 1))
            val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
            val bright = (r + g + b) / 3
            mask[yy * sw + xx] = bright > 190 && abs(r - g) < 45 && abs(g - b) < 55
        }

        val seen = BooleanArray(mask.size)
        val qx = IntArray(mask.size.coerceAtMost(200000)); val qy = IntArray(qx.size)
        val result = mutableListOf<Tile>()
        val minPx = (w * 0.055f / scale).toInt().coerceAtLeast(12)
        val maxPx = (w * 0.16f / scale).toInt().coerceAtMost(sw / 2)

        for (sy in 0 until sh) for (sx in 0 until sw) {
            val start = sy * sw + sx
            if (!mask[start] || seen[start]) continue
            var head = 0; var tail = 0
            qx[tail] = sx; qy[tail] = sy; tail++; seen[start] = true
            var minX = sx; var maxX = sx; var minY = sy; var maxY = sy; var count = 0
            while (head < tail) {
                val x = qx[head]; val y = qy[head]; head++; count++
                if (x < minX) minX = x; if (x > maxX) maxX = x
                if (y < minY) minY = y; if (y > maxY) maxY = y
                val ns = intArrayOf(y * sw + x - 1, y * sw + x + 1, (y - 1) * sw + x, (y + 1) * sw + x)
                for (n in ns) {
                    if (n < 0 || n >= mask.size || seen[n] || !mask[n]) continue
                    val nx = n % sw; val ny = n / sw
                    if (nx !in 0 until sw || ny !in 0 until sh) continue
                    seen[n] = true
                    if (tail < qx.size) { qx[tail] = nx; qy[tail] = ny; tail++ }
                }
            }
            val bw = maxX - minX + 1; val bh = maxY - minY + 1
            if (count < 40 || bw !in minPx..maxPx || bh !in minPx..maxPx) continue
            val aspect = bw.toFloat() / bh
            if (aspect !in 0.68f..1.42f) continue
            val cx = ((minX + maxX + 1) * scale / 2f).coerceIn(0f, (w - 1).toFloat())
            val cy = (y0 + (minY + maxY + 1) * scale / 2f).coerceIn(0f, (h - 1).toFloat())
            val size = (minOf(bw, bh) * scale * 0.72f).toInt().coerceAtLeast(20)
            result += Tile(cx, cy, descriptor(src, cx.toInt(), cy.toInt(), size))
        }
        val deduped = mutableListOf<Tile>()
        for (t in result) {
            if (deduped.none { abs(it.cx - t.cx) < w * 0.025f && abs(it.cy - t.cy) < w * 0.025f }) deduped += t
        }
        return deduped
    }

    private fun descriptor(src: Bitmap, cx: Int, cy: Int, size: Int): FloatArray {
        val n = 10; val out = FloatArray(n * n * 3); val half = size / 2; var k = 0
        for (j in 0 until n) for (i in 0 until n) {
            val x = (cx - half + ((i + 0.5f) * size / n)).toInt().coerceIn(0, src.width - 1)
            val y = (cy - half + ((j + 0.5f) * size / n)).toInt().coerceIn(0, src.height - 1)
            val c = src.getPixel(x, y)
            out[k++] = ((c shr 16) and 255) / 255f
            out[k++] = ((c shr 8) and 255) / 255f
            out[k++] = (c and 255) / 255f
        }
        return out
    }
}
