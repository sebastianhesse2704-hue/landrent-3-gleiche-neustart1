package com.landrent.cleanbot

import android.graphics.Bitmap
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.sqrt

/** On-device visual solver. It groups tiles by appearance; no fruit list is hardcoded. */
class BotEngine(private val tap: (Float, Float) -> Boolean) {
    @Volatile var enabled = false
    private var lastTapAt = 0L

    fun process(frame: Bitmap) {
        if (!enabled) return
        val now = SystemClock.uptimeMillis()
        if (now - lastTapAt < 650) return

        val board = detectTiles(frame, 0.23f, 0.78f)
        if (board.isEmpty()) return
        val tray = detectTiles(frame, 0.06f, 0.20f)
        val boardGroups = cluster(board)
        val trayGroups = cluster(tray)

        var best: Tile? = null
        var bestScore = Int.MIN_VALUE
        for (group in boardGroups) {
            val trayCount = trayGroups.count { appearanceDistance(group[0], it[0]) < 0.18f }
            // Always make progress. A new board can have no pair in the tray
            // yet; the old solver then did nothing forever. Prefer a tile that
            // completes a tray pair, otherwise prepare a useful board group.
            val score = when {
                trayCount >= 2 -> 10000 + trayCount * 100 + group.size
                trayCount == 1 -> 5000 + group.size
                group.size >= 3 -> 3000 + group.size
                group.size == 2 -> 2000 + group.size
                else -> 1000
            }
            if (score > bestScore) { bestScore = score; best = group.firstOrNull() }
        }
        if (best != null && tap(best.cx, best.cy)) lastTapAt = now
    }

    private data class Tile(val cx: Float, val cy: Float, val desc: FloatArray)

    private fun cluster(tiles: List<Tile>): List<List<Tile>> {
        val out = mutableListOf<MutableList<Tile>>()
        for (t in tiles) {
            val target = out.firstOrNull { appearanceDistance(t, it[0]) < 0.16f }
            if (target == null) out += mutableListOf(t) else target.add(t)
        }
        return out
    }

    private fun appearanceDistance(a: Tile, b: Tile): Float {
        var s = 0.0
        for (i in a.desc.indices) { val d = a.desc[i] - b.desc[i]; s += d * d }
        return sqrt(s / a.desc.size).toFloat()
    }

    private fun detectTiles(src: Bitmap, topFrac: Float, bottomFrac: Float): List<Tile> {
        val w = src.width
        val h = src.height
        val y0 = (h * topFrac).toInt().coerceAtLeast(0)
        val y1 = (h * bottomFrac).toInt().coerceAtMost(h)
        val scale = 4
        val sw = w / scale
        val sh = (y1 - y0) / scale
        if (sw < 80 || sh < 60) return emptyList()

        // Look for the coloured/contrasting part of a tile rather than for its
        // white background. The previous detector mostly detected the board
        // background, so it often produced zero usable tiles.
        val mask = BooleanArray(sw * sh)
        for (yy in 0 until sh) for (xx in 0 until sw) {
            val sx = (xx * scale + scale / 2).coerceIn(0, w - 1)
            val sy = (y0 + yy * scale + scale / 2).coerceIn(0, h - 1)
            val c = src.getPixel(sx, sy)
            val r = (c ushr 16) and 255
            val g = (c ushr 8) and 255
            val b = c and 255
            val mx = maxOf(r, g, b)
            val mn = minOf(r, g, b)
            val saturation = mx - mn
            val brightness = (r + g + b) / 3
            mask[yy * sw + xx] = brightness > 45 && saturation > 32
        }

        val seen = BooleanArray(mask.size)
        val qx = IntArray(mask.size.coerceAtMost(300000))
        val qy = IntArray(qx.size)
        val raw = mutableListOf<Tile>()

        for (sy in 1 until sh - 1) for (sx in 1 until sw - 1) {
            val start = sy * sw + sx
            if (!mask[start] || seen[start]) continue
            var head = 0
            var tail = 0
            qx[tail] = sx; qy[tail] = sy; tail++
            seen[start] = true
            var minX = sx; var maxX = sx; var minY = sy; var maxY = sy; var count = 0
            while (head < tail) {
                val x = qx[head]; val y = qy[head]; head++; count++
                minX = minOf(minX, x); maxX = maxOf(maxX, x)
                minY = minOf(minY, y); maxY = maxOf(maxY, y)
                for (dy in -1..1) for (dx in -1..1) {
                    if (dx == 0 && dy == 0) continue
                    val nx = x + dx; val ny = y + dy
                    if (nx !in 1 until sw - 1 || ny !in 1 until sh - 1) continue
                    val n = ny * sw + nx
                    if (!seen[n] && mask[n] && tail < qx.size) {
                        seen[n] = true; qx[tail] = nx; qy[tail] = ny; tail++
                    }
                }
            }

            val bw = maxX - minX + 1
            val bh = maxY - minY + 1
            // Fruit artwork should form a compact region. Very thin regions
            // are UI text/lines; huge regions are the board background.
            if (count < 18 || count > (sw * sh) / 5) continue
            if (bw < 5 || bh < 5 || bw > sw / 2 || bh > sh / 2) continue
            val aspect = bw.toFloat() / bh.toFloat()
            if (aspect !in 0.35f..2.8f) continue

            val cx = ((minX + maxX + 1) * scale / 2f).coerceIn(0f, (w - 1).toFloat())
            val cy = (y0 + (minY + maxY + 1) * scale / 2f).coerceIn(0f, (h - 1).toFloat())
            val size = (maxOf(bw, bh) * scale * 1.8f).toInt().coerceIn(24, (w * 0.18f).toInt())
            raw += Tile(cx, cy, descriptor(src, cx.toInt(), cy.toInt(), size))
        }

        // Several coloured parts can belong to one fruit. Merge nearby
        // candidates and keep the strongest/central one.
        val out = mutableListOf<Tile>()
        val mergeX = w * 0.055f
        val mergeY = w * 0.055f
        for (t in raw) {
            val old = out.firstOrNull { abs(it.cx - t.cx) < mergeX && abs(it.cy - t.cy) < mergeY }
            if (old == null) out += t
        }
        return out
    }

    private fun descriptor(src: Bitmap, cx: Int, cy: Int, size: Int): FloatArray {
        val n = 10; val out = FloatArray(n * n * 3); val half = size / 2; var k = 0
        for (j in 0 until n) for (i in 0 until n) {
            val x = (cx - half + ((i + 0.5f) * size / n)).toInt().coerceIn(0, src.width - 1)
            val y = (cy - half + ((j + 0.5f) * size / n)).toInt().coerceIn(0, src.height - 1)
            val c = src.getPixel(x, y)
            out[k++] = ((c shr 16) and 255) / 255f
            out[k++] = ((c shr 8) and 255) / 255f
            out[k++] = (c and 255) / 255f
        }
        return out
    }
}
