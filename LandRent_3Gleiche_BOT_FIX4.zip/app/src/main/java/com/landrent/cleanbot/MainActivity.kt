package com.landrent.cleanbot

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.ServiceConnection
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var botButton: Button
    private val projectionRequest = 501
    private var captureService: CaptureService? = null
    private var bound = false

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            captureService = (service as CaptureService.LocalBinder).getService(); bound = true
            botButton.isEnabled = true
        }
        override fun onServiceDisconnected(name: ComponentName?) { captureService = null; bound = false; botButton.isEnabled = false }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(40,40,40,40) }
        status = TextView(this).apply { textSize=19f; gravity=Gravity.CENTER; text="Bereit" }
        layout.addView(status)
        layout.addView(Button(this).apply { text="BEDIENUNGSHILFE ÖFFNEN"; setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } })
        layout.addView(Button(this).apply { text="BILDSCHIRMZUGRIFF AKTIVIEREN"; setOnClickListener { requestProjection() } })
        layout.addView(Button(this).apply { text="BILDSCHIRM TESTEN"; setOnClickListener {
            status.text = if (CaptureService.running) "BILDSCHIRMZUGRIFF AKTIV ✓" else "BILDSCHIRMZUGRIFF NICHT AKTIV"
            Toast.makeText(this@MainActivity, if (CaptureService.running) "Bildschirmzugriff läuft." else "Bitte zuerst Bildschirmzugriff aktivieren.", Toast.LENGTH_LONG).show()
        } })
        botButton = Button(this).apply {
            text = "3-GLEICHE-BOT STARTEN"; isEnabled = false
            setOnClickListener {
                val service = captureService ?: return@setOnClickListener
                val enable = !service.isBotEnabled(); service.setBotEnabled(enable)
                text = if (enable) "3-GLEICHE-BOT STOPPEN" else "3-GLEICHE-BOT STARTEN"
                status.text = if (enable) "BOT LÄUFT – Spielfeld öffnen" else "BOT GESTOPPT"
            }
        }
        layout.addView(botButton)
        setContentView(layout)
    }

    private fun requestProjection() {
        val manager = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(manager.createScreenCaptureIntent(), projectionRequest)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != projectionRequest) return
        if (resultCode != RESULT_OK || data == null) {
            status.text = "BILDSCHIRMFREIGABE ABGEBROCHEN"
            Toast.makeText(this, "Samsung hat keine Bildschirmfreigabe-Daten geliefert.", Toast.LENGTH_LONG).show(); return
        }
        status.text = "BILDSCHIRMZUGRIFF STARTET…"
        val serviceIntent = Intent(this, CaptureService::class.java)
        startForegroundService(serviceIntent)
        bindService(serviceIntent, connection, BIND_AUTO_CREATE)
        window.decorView.postDelayed({
            val service = captureService
            if (bound && service != null) service.startProjection(resultCode, data)
            else { status.text = "DIENST NICHT BEREIT"; Toast.makeText(this, "Bildschirmdienst konnte nicht verbunden werden.", Toast.LENGTH_LONG).show() }
        }, 300)
    }

    override fun onDestroy() { if (bound) { unbindService(connection); bound=false }; super.onDestroy() }
}
