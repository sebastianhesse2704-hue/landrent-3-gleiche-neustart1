plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.landrent.cleanbot"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.landrent.cleanbot"
        minSdk = 30
        targetSdk = 35
        versionCode = 11
        versionName = "11.0"
    }
}
